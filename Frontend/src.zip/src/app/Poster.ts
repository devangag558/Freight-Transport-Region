export class IVehicle {
  vehicleNumber?: String;
  vehicleName?: String;
  maxLiftingCapacity?: Number;
  retireDate?: Date;
  vehicleStatus?: String;
  harborLocation?: String;
  country?: String;
}
